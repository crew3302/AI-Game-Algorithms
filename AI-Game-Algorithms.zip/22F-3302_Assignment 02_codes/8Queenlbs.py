import pygame
import numpy as np
import random
import os
import time

pygame.init()

WIDTH, HEIGHT = 600, 600
BOARD_SIZE = 8
CELL_SIZE = WIDTH // BOARD_SIZE
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
K = 5 

QUEEN_IMAGE_PATH = os.path.join(os.path.dirname(__file__), "queen.png")
QUEEN_IMAGE = pygame.image.load(QUEEN_IMAGE_PATH)
QUEEN_IMAGE = pygame.transform.scale(QUEEN_IMAGE, (CELL_SIZE, CELL_SIZE))

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("8-Queens Problem - Local Beam Search")


def draw_board(board):
   screen.fill(WHITE)
   for row in range(BOARD_SIZE):
       for col in range(BOARD_SIZE):
           if (row + col) % 2 == 0:
               pygame.draw.rect(screen, BLACK, (col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE))
           if board[row] == col:
               screen.blit(QUEEN_IMAGE, (col * CELL_SIZE, row * CELL_SIZE))
   pygame.display.update()


def attacking_pairs(board):
   attacks = 0
   for i in range(BOARD_SIZE):
       for j in range(i + 1, BOARD_SIZE):
           if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j):
               attacks += 1
   return attacks


def generate_neighbors(board):
   neighbors = []
   for row in range(BOARD_SIZE):
       for new_col in range(BOARD_SIZE):
           if new_col != board[row]:
               new_board = board.copy()
               new_board[row] = new_col
               neighbors.append(new_board)
   return neighbors


def local_beam_search():
   states = [np.random.randint(0, BOARD_SIZE, BOARD_SIZE) for _ in range(K)]
   states = sorted(states, key=attacking_pairs) 

   while True:
       best_state = states[0]
       draw_board(best_state)

       if attacking_pairs(best_state) == 0:
           print("\nSolution Found!")
           return best_state

       all_candidates = []
       for state in states:
           all_candidates.extend(generate_neighbors(state))

       states = sorted(all_candidates, key=attacking_pairs)[:K]

       print(f"Best attacking pairs: {attacking_pairs(states[0])}")

       time.sleep(0.1) 


# main code
final_board = local_beam_search()

draw_board(final_board)

running = True
while running:
   for event in pygame.event.get():
       if event.type == pygame.QUIT:
           running = False

pygame.quit()
