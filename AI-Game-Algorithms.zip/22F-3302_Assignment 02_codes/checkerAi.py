import numpy as np
import pygame
import sys
import time

pygame.init()

# Constants for graphics
WIDTH, HEIGHT = 600, 600
WHITE = (255, 255, 255)c
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
CELL_SIZE = WIDTH // 8
KING_RED = (200, 0, 0)
KING_BLUE = (0, 0, 200)

class Checkers:
    def __init__(self, ai_player="B", use_alpha_beta=True, depth_limit=4):
        self.board = self.create_board()
        self.window = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Checkers with AI")
        self.selected_piece = None
        self.current_player = "R"
        self.ai_player = ai_player
        self.human_player = "B" if ai_player == "R" else "R"
        self.use_alpha_beta = use_alpha_beta
        self.depth_limit = depth_limit
        self.nodes_expanded = 0
        self.draw_board()

    def create_board(self):
        board = np.full((8, 8), "-", dtype=str)
        for row in range(3):
            for col in range(8):
                if (row + col) % 2 == 1:
                    board[row][col] = "B"
        for row in range(5, 8):
            for col in range(8):
                if (row + col) % 2 == 1:
                    board[row][col] = "R"
        return board

    def draw_board(self):
        self.window.fill(WHITE)
        for row in range(8):
            for col in range(8):
                color = BLACK if (row + col) % 2 == 0 else WHITE
                pygame.draw.rect(
                    self.window,
                    color,
                    (col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE),
                )
                piece = self.board[row][col]
                if piece in ["R", "B"]:
                    pygame.draw.circle(
                        self.window,
                        RED if piece == "R" else BLUE,
                        (
                            col * CELL_SIZE + CELL_SIZE // 2,
                            row * CELL_SIZE + CELL_SIZE // 2,
                        ),
                        CELL_SIZE // 2 - 5,
                    )
                elif piece in ["RK", "BK"]:
                    pygame.draw.circle(
                        self.window,
                        KING_RED if piece == "RK" else KING_BLUE,
                        (
                            col * CELL_SIZE + CELL_SIZE // 2,
                            row * CELL_SIZE + CELL_SIZE // 2,
                        ),
                        CELL_SIZE // 2 - 5,
                    )
        pygame.display.update()

    def valid_moves(self, row, col, board=None):
        if board is None:
            board = self.board
        moves = []
        piece = board[row][col]
        if piece == "-":
            return moves

        directions = [(-1, -1), (-1, 1)] if piece == "R" else [(1, -1), (1, 1)]
        if piece in ["RK", "BK"]:
            directions = [(-1, -1), (-1, 1), (1, -1), (1, 1)]

        for drow, dcol in directions:
            new_row, new_col = row + drow, col + dcol
            if 0 <= new_row < 8 and 0 <= new_col < 8:
                if board[new_row][new_col] == "-":
                    moves.append((new_row, new_col))
                elif board[new_row][new_col][0] != piece[0]:
                    jump_row, jump_col = new_row + drow, new_col + dcol
                    if (
                        0 <= jump_row < 8
                        and 0 <= jump_col < 8
                        and board[jump_row][jump_col] == "-"
                    ):
                        moves.append((jump_row, jump_col))
        return moves

    def get_all_moves(self, player, board=None):
        if board is None:
            board = self.board
        all_moves = []
        for row in range(8):
            for col in range(8):
                if board[row][col] in [player, player + "K"]:
                    moves = self.valid_moves(row, col, board)
                    for move in moves:
                        all_moves.append(((row, col), move))
        return all_moves

    def apply_move(self, move, board):
        (old_row, old_col), (new_row, new_col) = move
        new_board = board.copy()
        piece = new_board[old_row][old_col]
        new_board[new_row][new_col] = piece
        new_board[old_row][old_col] = "-"

        if abs(new_row - old_row) == 2:
            mid_row, mid_col = (new_row + old_row) // 2, (new_col + old_col) // 2
            new_board[mid_row][mid_col] = "-"

        if new_row == 0 and piece == "R":
            new_board[new_row][new_col] = "RK"
        elif new_row == 7 and piece == "B":
            new_board[new_row][new_col] = "BK"

        return new_board

    def evaluate(self, board):
        red_count = np.sum(board == "R") + 2 * np.sum(board == "RK")
        blue_count = np.sum(board == "B") + 2 * np.sum(board == "BK")
        return (
            blue_count - red_count if self.ai_player == "B" else red_count - blue_count
        )

    def minimax(self, board, depth, is_maximizing):
        self.nodes_expanded += 1
        if depth >= self.depth_limit or self.is_game_over(board):
            return self.evaluate(board)

        moves = self.get_all_moves(
            self.ai_player if is_maximizing else self.human_player, board
        )
        if not moves:
            return -float("inf") if is_maximizing else float("inf")

        if is_maximizing:
            best_score = -float("inf")
            for move in moves:
                new_board = self.apply_move(move, board)
                score = self.minimax(new_board, depth + 1, False)
                best_score = max(best_score, score)
            return best_score
        else:
            best_score = float("inf")
            for move in moves:
                new_board = self.apply_move(move, board)
                score = self.minimax(new_board, depth + 1, True)
                best_score = min(best_score, score)
            return best_score

    def minimax_alpha_beta(self, board, depth, alpha, beta, is_maximizing):
        self.nodes_expanded += 1
        if depth >= self.depth_limit or self.is_game_over(board):
            return self.evaluate(board)

        moves = self.get_all_moves(
            self.ai_player if is_maximizing else self.human_player, board
        )
        if not moves:
            return -float("inf") if is_maximizing else float("inf")

        if is_maximizing:
            best_score = -float("inf")
            for move in moves:
                new_board = self.apply_move(move, board)
                score = self.minimax_alpha_beta(
                    new_board, depth + 1, alpha, beta, False
                )
                best_score = max(best_score, score)
                alpha = max(alpha, best_score)
                if beta <= alpha:
                    break
            return best_score
        else:
            best_score = float("inf")
            for move in moves:
                new_board = self.apply_move(move, board)
                score = self.minimax_alpha_beta(new_board, depth + 1, alpha, beta, True)
                best_score = min(best_score, score)
                beta = min(beta, best_score)
                if beta <= alpha:
                    break
            return best_score

    def ai_move(self):
        print(f"AI ({self.ai_player}) is thinking...")
        start_time = time.time()
        self.nodes_expanded = 0
        best_score = -float("inf")
        best_move = None

        moves = self.get_all_moves(self.ai_player)
        if not moves:
            print("No moves available for AI! Game might be over.")
            return

        for move in moves:
            new_board = self.apply_move(move, self.board)
            if self.use_alpha_beta:
                score = self.minimax_alpha_beta(
                    new_board, 0, -float("inf"), float("inf"), False
                )
            else:
                score = self.minimax(new_board, 0, False)
            if score > best_score:
                best_score = score
                best_move = move

        if best_move:
            self.board = self.apply_move(best_move, self.board)
            self.draw_board()
            end_time = time.time()
            print(
                f"AI Move - Time: {(end_time - start_time):.4f}s, Nodes Expanded: {self.nodes_expanded}"
            )
        else:
            print("AI found no valid move!")

    def human_move(self, row, col):
        if self.selected_piece:
            old_row, old_col = self.selected_piece
            valid_moves = self.valid_moves(old_row, old_col)
            if (row, col) in valid_moves:
                move = ((old_row, old_col), (row, col))
                self.board = self.apply_move(move, self.board)
                self.draw_board()
                self.selected_piece = None
                return True
            else:
                print(
                    f"Invalid move attempted: {old_row},{old_col} to {row},{col}. Valid moves: {valid_moves}"
                )
                # Deselect if clicking the same piece again
                if (row, col) == (old_row, old_col):
                    self.selected_piece = None
                    print(f"Deselected {row},{col}")
        if self.board[row][col] in [self.human_player, self.human_player + "K"]:
            self.selected_piece = (row, col)
            valid_moves = self.valid_moves(row, col)
            print(f"Selected {row},{col}. Valid moves: {valid_moves}")
        return False

    def is_game_over(self, board):
        red_pieces = np.any(np.isin(board, ["R", "RK"]))
        blue_pieces = np.any(np.isin(board, ["B", "BK"]))
        red_moves = bool(self.get_all_moves("R", board))
        blue_moves = bool(self.get_all_moves("B", board))
        return not (red_pieces and red_moves) or not (blue_pieces and blue_moves)

def main():
    print("Choose AI mode: (1) Minimax, (2) Alpha-Beta")
    mode = input("Enter 1 or 2: ").strip()
    use_alpha_beta = mode == "2"

    print("Enter AI depth limit (recommended 2-6):")
    depth_limit = int(input().strip())

    print("Should AI play as Blue (B) or Red (R)? (b/r)")
    ai_player = "B" if input().strip().lower() == "b" else "R"

    game = Checkers(
        ai_player=ai_player, use_alpha_beta=use_alpha_beta, depth_limit=depth_limit
    )

    if game.ai_player == "R":
        game.current_player = "R"
        game.ai_move()
        game.current_player = "B"

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if (
                event.type == pygame.MOUSEBUTTONDOWN
                and game.current_player == game.human_player
            ):
                x, y = event.pos
                row, col = y // CELL_SIZE, x // CELL_SIZE
                if game.human_move(row, col):
                    print(f"Human ({game.human_player}) moved!")
                    if game.is_game_over(game.board):
                        winner = (
                            "Red"
                            if not np.any(np.isin(game.board, ["B", "BK"]))
                            else "Blue"
                        )
                        print(f"{winner} wins!")
                        pygame.time.delay(2000)
                        running = False
                    else:
                        game.current_player = game.ai_player
                        game.ai_move()
                        print(
                            f"Turn switched to AI ({game.ai_player}), now back to human"
                        )
                        if game.is_game_over(game.board):
                            winner = (
                                "Red"
                                if not np.any(np.isin(game.board, ["B", "BK"]))
                                else "Blue"
                            )
                            print(f"{winner} wins!")
                            pygame.time.delay(2000)
                            running = False
                        else:
                            game.current_player = game.human_player
                            print(f"Turn switched back to human ({game.human_player})")
                            if not game.get_all_moves(game.human_player):
                                print(
                                    f"No moves left for {game.human_player}! {game.ai_player} wins!"
                                )
                                pygame.time.delay(2000)
                                running = False
                else:
                    print(
                        f"Click at {row},{col} didn’t result in a move. Current player: {game.current_player}"
                    )
        pygame.display.update()
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
