import pygame
import numpy as np
import random
import os
import time

pygame.init()

SCREEN_WIDTH, SCREEN_HEIGHT = 600, 600
BOARD_ROWS, BOARD_COLS = 8, 8
CELL_WIDTH = SCREEN_WIDTH // BOARD_ROWS
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (0, 0, 0)

QUEEN_IMAGE_FILE = os.path.join(os.path.dirname(__file__), "queen.png")
QUEEN_IMAGE = pygame.image.load(QUEEN_IMAGE_FILE)
QUEEN_IMAGE = pygame.transform.scale(QUEEN_IMAGE, (CELL_WIDTH, CELL_WIDTH))

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("8-Queens Problem - Hill Climbing")

def draw_board(board):
    screen.fill(COLOR_WHITE)
    for row in range(BOARD_ROWS):
        for col in range(BOARD_COLS):
            if (row + col) % 2 == 0:
                pygame.draw.rect(screen, COLOR_BLACK, (col * CELL_WIDTH, row * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH))
            if board[row] == col:
                screen.blit(QUEEN_IMAGE, (col * CELL_WIDTH, row * CELL_WIDTH))
    pygame.display.update()

def count_attacking_pairs(board):
    attacks = 0
    for i in range(BOARD_ROWS):
        for j in range(i + 1, BOARD_ROWS):
            if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j):
                attacks += 1
    return attacks

def generate_best_neighbor_board(board):
    best_neighbor_board = board.copy()
    best_cost_count = count_attacking_pairs(board)

    for row in range(BOARD_ROWS):
        original_col = board[row]

        for new_col in range(BOARD_COLS):
            if new_col != original_col:
                new_board = board.copy()
                new_board[row] = new_col
                new_cost_count = count_attacking_pairs(new_board)

                if new_cost_count < best_cost_count:
                    best_neighbor_board = new_board
                    best_cost_count = new_cost_count

        board[row] = original_col

    return best_neighbor_board, best_cost_count

def hill_climbing_algorithm():
    restarts = 0

    while True:
        current_board = np.random.randint(0, BOARD_ROWS, BOARD_ROWS)
        current_cost_count = count_attacking_pairs(current_board)

        print(f"Restart {restarts}: Initial Attacking Pairs = {current_cost_count}")

        while True:
            draw_board(current_board)
            best_neighbor_board, best_cost_count = generate_best_neighbor_board(current_board)

            if best_cost_count >= current_cost_count:
                break

            current_board = best_neighbor_board
            current_cost_count = best_cost_count
            print(f"Improved: Attacking Pairs = {current_cost_count}")

            time.sleep(0.1)

            if current_cost_count == 0:
                print("\nSolution Found!")
                return current_board

        restarts += 1

final_board = hill_climbing_algorithm()

draw_board(final_board)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()