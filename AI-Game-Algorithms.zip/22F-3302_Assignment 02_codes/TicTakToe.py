import numpy as np
import pygame
import sys
import time

pygame.init()

SCREEN_WIDTH, SCREEN_HEIGHT = 600, 600
GRID_LINE_WIDTH = 8
BOARD_SIZE = 4
CELL_DIM = SCREEN_WIDTH // BOARD_SIZE
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (30, 30, 30)
COLOR_RED = (255, 69, 0)
COLOR_BLUE = (65, 105, 225)
GRID_COLOR = (176, 196, 222)
X_COLOR =  (139, 0, 0)
O_COLOR = (75, 0, 130) 


class TicTacToeGame:
    def __init__(self, ai_starts=False, enable_alpha_beta=True, search_depth=4):
        self.board = np.full((BOARD_SIZE, BOARD_SIZE), '-')
        self.ai_starts = ai_starts
        self.enable_alpha_beta = enable_alpha_beta
        self.current_turn = 'X' if not ai_starts else 'O'
        self.window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Tic-Tac-Toe")
        self.window.fill(COLOR_WHITE)
        self.draw_grid()
        self.expanded_nodes = 0
        self.search_depth = search_depth
        if self.ai_starts:
            self.computer_move()

    def draw_grid(self):
        for row in range(1, BOARD_SIZE):
            pygame.draw.line(self.window, GRID_COLOR, (0, row * CELL_DIM), (SCREEN_WIDTH, row * CELL_DIM), GRID_LINE_WIDTH)
        for col in range(1, BOARD_SIZE):
            pygame.draw.line(self.window, GRID_COLOR, (col * CELL_DIM, 0), (col * CELL_DIM, SCREEN_HEIGHT), GRID_LINE_WIDTH)
        pygame.display.update()

    def draw_move(self, row, col):
        center_x = col * CELL_DIM + CELL_DIM // 2
        center_y = row * CELL_DIM + CELL_DIM // 2
        if self.current_turn == 'X':
            pygame.draw.line(self.window, X_COLOR, (center_x - 30, center_y - 30), (center_x + 30, center_y + 30), 8)
            pygame.draw.line(self.window, X_COLOR, (center_x + 30, center_y - 30), (center_x - 30, center_y + 30), 8)
        else:
            pygame.draw.circle(self.window, O_COLOR, (center_x, center_y), 30, 8)
        pygame.display.update()

    def make_move(self, row, col):
        if self.board[row, col] == '-':
            self.board[row, col] = self.current_turn
            self.draw_move(row, col)
            if self.is_winner(self.current_turn):
                print(f"{self.current_turn} wins!")
                pygame.time.delay(2000)
                pygame.quit()
                sys.exit()
            self.current_turn = 'O' if self.current_turn == 'X' else 'X'
            if not self.is_board_full() and not self.is_winner('X') and not self.is_winner('O'):
                if self.current_turn == 'O':
                    self.computer_move()

    def is_winner(self, player):
        for row in self.board:
            if all(cell == player for cell in row):
                return True
        for col in range(BOARD_SIZE):
            if all(self.board[row][col] == player for row in range(BOARD_SIZE)):
                return True
        if all(self.board[i][i] == player for i in range(BOARD_SIZE)) or all(self.board[i][BOARD_SIZE - i - 1] == player for i in range(BOARD_SIZE)):
            return True
        return False

    def is_board_full(self):
        return all(cell != '-' for row in self.board for cell in row)

    def evaluate_board(self):
        if self.is_winner('O'):
            return 100
        elif self.is_winner('X'):
            return -100
        elif self.is_board_full():
            return 0
        return 0  

    def minimax(self, board, depth, is_maximizing, alpha=None, beta=None):
        self.expanded_nodes += 1
        if self.is_winner('O'):
            return 1
        elif self.is_winner('X'):
            return -1
        elif self.is_board_full():
            return 0
        elif depth == self.search_depth:
            return self.evaluate_board()

        if is_maximizing:
            best_score = -float('inf')
            for i in range(BOARD_SIZE):
                for j in range(BOARD_SIZE):
                    if board[i][j] == '-':
                        board[i][j] = 'O'
                        score = self.minimax(board.copy(), depth + 1, False, alpha, beta)
                        board[i][j] = '-'
                        best_score = max(score, best_score)
                        if self.enable_alpha_beta:
                            alpha = max(alpha, best_score)
                            if beta is not None and beta <= alpha:
                                return best_score
            return best_score
        else:
            best_score = float('inf')
            for i in range(BOARD_SIZE):
                for j in range(BOARD_SIZE):
                    if board[i][j] == '-':
                        board[i][j] = 'X'
                        score = self.minimax(board.copy(), depth + 1, True, alpha, beta)
                        board[i][j] = '-'
                        best_score = min(score, best_score)
                        if self.enable_alpha_beta:
                            beta = min(beta, best_score)
                            if alpha is not None and beta <= alpha:
                                return best_score
            return best_score

    def best_move(self):
        best_score = -float('inf')
        best_moves = []
        alpha = -float('inf')
        beta = float('inf')
        for i in range(BOARD_SIZE):
            for j in range(BOARD_SIZE):
                if self.board[i][j] == '-':
                    self.board[i][j] = 'O'
                    score = self.minimax(self.board.copy(), 0, False, alpha, beta)
                    self.board[i][j] = '-'
                    if score > best_score:
                        best_score = score
                        best_moves = [(i, j)]
                    elif score == best_score:
                        best_moves.append((i, j))
        return best_moves[np.random.randint(len(best_moves))] if best_moves else None

    def computer_move(self):
        print("AI is making a move...")
        start_time = time.time()
        self.expanded_nodes = 0
        move = self.best_move()
        if move:
            self.make_move(move[0], move[1])
        else:
            if self.is_board_full():
                print("Draw")
                pygame.quit()
                sys.exit()
            else:
                print("Error: No move available, but game not over")
                pygame.quit()
                sys.exit()
        end_time = time.time()
        print(f"Nodes expanded: {self.expanded_nodes}, Execution time: {end_time - start_time:.4f} sec")

if __name__ == "__main__":
    ai_starts = input("Should AI play first? (y/n): ").lower() == 'y'
    use_alpha_beta = input("Use Alpha-Beta Pruning? (y/n): ").lower() == 'y'
    game_instance = TicTacToeGame(ai_starts, use_alpha_beta)
    game_running = True
    while game_running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_running = False
            if event.type == pygame.MOUSEBUTTONDOWN and game_instance.current_turn == 'X':
                x, y = event.pos
                row = y // CELL_DIM
                col = x // CELL_DIM
                if game_instance.board[row, col] == '-':
                    game_instance.make_move(row, col)
    pygame.quit()
