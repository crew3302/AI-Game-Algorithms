import pygame
import numpy as np
import random
import math
import os
import time

pygame.init()

screen_width, screen_height = 600, 600
board_dimension = 8
cell_dimension = screen_width // board_dimension
color_white = (255, 255, 255)
color_black = (0, 0, 0)

queen_image_path = os.path.join(os.path.dirname(__file__), "queen.png")
queen_image = pygame.image.load(queen_image_path)
queen_image = pygame.transform.scale(queen_image, (cell_dimension, cell_dimension))

display_screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("8-Queens Problem - Simulated Annealing")

def draw_game_board(board_layout):
   display_screen.fill(color_white)
   for row_index in range(board_dimension):
       for col_index in range(board_dimension):
           if (row_index + col_index) % 2 == 0:
               pygame.draw.rect(display_screen, color_black, (col_index * cell_dimension, row_index * cell_dimension, cell_dimension, cell_dimension))
           if board_layout[row_index] == col_index:
               display_screen.blit(queen_image, (col_index * cell_dimension, row_index * cell_dimension))
   pygame.display.update()


def count_attacking_pairs(board_layout):
   total_attacks = 0
   for i in range(board_dimension):
       for j in range(i + 1, board_dimension):
           if board_layout[i] == board_layout[j] or abs(board_layout[i] - board_layout[j]) == abs(i - j):
               total_attacks += 1
   return total_attacks

def create_neighbor_board(board_layout):
   neighbor_board = board_layout.copy()
   selected_row = random.randint(0, board_dimension - 1)
   new_column = random.randint(0, board_dimension - 1)
   while new_column == board_layout[selected_row]: 
       new_column = random.randint(0, board_dimension - 1)
   neighbor_board[selected_row] = new_column
   return neighbor_board


def simulated_annealing_algorithm(initial_board_state):
   temp = 100.0 
   cooling_factor = 0.995 
   min_temp = 0.1 
   current_board = initial_board_state
   current_board_cost = count_attacking_pairs(current_board)

   iteration_count = 0 

   while temp > min_temp:
       new_board_state = create_neighbor_board(current_board)
       new_board_cost = count_attacking_pairs(new_board_state)

       energy_difference = current_board_cost - new_board_cost

       if energy_difference > 0 or math.exp(energy_difference / temp) > random.random():
           current_board = new_board_state
           current_board_cost = new_board_cost
           draw_game_board(current_board) 

       temp *= cooling_factor
       iteration_count += 1

       print(f"Iteration {iteration_count}: Attacking pairs = {current_board_cost}, Temperature = {temp:.2f}")

       if current_board_cost == 0:
           print("\nSolution Found!")
           break

       time.sleep(0.1) 

   return current_board

# main code
initial_board = np.random.randint(0, board_dimension, board_dimension) 
draw_game_board(initial_board)

  
final_board_state = simulated_annealing_algorithm(initial_board)

  
draw_game_board(final_board_state)

game_running = True
while game_running:
   for event in pygame.event.get():
       if event.type == pygame.QUIT:
           game_running = False

pygame.quit()